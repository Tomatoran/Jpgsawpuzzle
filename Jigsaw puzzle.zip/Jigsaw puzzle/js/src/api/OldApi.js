/** @language chinese
 * <p>新版API已经基本完整，如果您习惯旧版本的API，旧版api地址如下：</p>
 * <p><a href="http://lufylegend.com/lufylegend/oldapi" target="_blank">http://lufylegend.com/lufylegend/oldapi</a></p>
 * @class 旧版API
 * @since 1.9.0
 * @public
 */